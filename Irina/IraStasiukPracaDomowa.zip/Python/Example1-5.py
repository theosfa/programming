

#Przykład 1

# a = float(input("Wczytaj a: "))
# b = float(input("Wczytaj b: "))
#
# P = a * b
# print(P)

# Przykład 2

# imie=input("Podaj swoje imię:")
# wiek=int(input("Ile masz lat?"))
#
# print("Masz na imię", imie, "i masz", wiek, "lat")
# input("\n Aby zakończyć program, naciśnij klawisz Enter")

# Przykład 3

# x=int(input("Podaj podstawe: "))
# y=int(input("Podaj wykaldnik: "))
#
# wynik=x**y #znaki ** oznaczają potęgowanie
#
# print(x,"do potegi", y, "=",wynik)
# input("\nAby zakończyć program, naciśnij klawisz Enter.")

# Przykład 4

# a=float(input("Wprowadz bok a: "))
# b=float(input("Wprowadz bok b: "))
# c=float(input("Wprowadz bok c: "))
#
# p=(a+b+c)/2
# pole=0,5**(p*(p-a)*(p-b)*(p-c))
#
# print("Połowa obwodu =", p)
# print("Pole trójkąta wynosi:", pole)
# input("\nAby zakończyć program, naciśnij klawisz Enter.")

# Przykład 5

import random
kostka_1=random.randint(1,6)
kostka_2=random.randrange(6)+1

wynik=kostka_1+kostka_2

print("Wyrzuciles", kostka_1, "oraz", kostka_2, "i uzyskales wynik=", wynik)
input("\nAby zakończyć program, naciśnij klawisz ENTER")
