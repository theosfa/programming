print(hex(123))
