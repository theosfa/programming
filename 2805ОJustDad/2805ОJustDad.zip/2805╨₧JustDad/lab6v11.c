// 11 - insert, gnome, merge, selection, comb

#include <stdio.h>
#include <stdlib.h>
#define RFACTOR (1.24733)

void insertionSort(int n, int *mass, int *count);
void mergeSort(int *a, int l, int r, int *count);
void gnomeSort(int n, int *a, int *count);
void comb_sort(int *array, int n, int *count);
void selectionSort(int *mass, int n, int *count);

void read_numbers(FILE* input, int size, int* numbers);
int numberCount(FILE* input);
void print_array(int* numbers, int size);

/**
 * Reads a file containing a list of integers and stores them in an array.
 *
 * @param input The file to read.
 * @param size The number of integers in the file.
 * @param numbers The array to store the integers in.
 *
 * @returns None
 */
int main() {
  FILE* input = fopen("l6v11.txt", "r");
  if (input == 0) {
    printf("cant open file\n");
    return 1;
  }
  int size = numberCount(input);
  int numbers[size];
  read_numbers(input, size, numbers);
  int insert = numbers;
  int insertCount = 0;
  int gnome = numbers;
  int gnomeCount = 0;
  int comb = numbers;
  int combCount = 0;
  int merge = numbers;
  int mergeCount = 0;
  int selection = numbers;
  int selectionCount = 0;
  insertionSort(size, insert, insertCount);
  gnomeSort(size, gnome, gnomeCount);
  mergesort(merge, 0, size, mergeCount);
  comb_sort(comb, size, combCount);
  selectionSort(selection, size, selectionCount);
  // print_array(insert, size);
  // print_array(gnome, size);
  // print_array(comb, size);
  // print_array(selection, size);
  // print_array(merge, size);
  printf("insertCount : %d", insertCount);
  printf("gnomeCount : %d", gnomeCount);
  printf("mergeCount : %d", mergeCount);
  printf("combCount : %d", combCount);
  printf("selectionCount : %d", selectionCount);
}

void read_numbers(FILE* input, int size, int* numbers) {
  fseek(input, 0, SEEK_SET);
  for (int i = 0; i < size; ++i) {
    fscanf(input, "%d", &numbers[i]);
  }
}

int numberCount(FILE* input) {
  fseek(input, 0, SEEK_SET);
  int counter = 0;
  while (1) {
    int value;
    if (fscanf(input, "%d", &value) == 1)
      counter++;
    if (feof(input))
      break;
  }
  return counter;
}

void print_array(int* numbers, int size) {
  for (int i = 0; i < size; ++i) {
    printf("%d ; ", numbers[i]);
  }
  printf("\n");
}

void insertionSort(int n, int *mass, int *count){
    int newElement, location;

    for (int i = 1; i < n; i++)
    {
        newElement = mass[i];
        location = i - 1;
        while(location >= 0 && mass[location] > newElement)
        {
            mass[location+1] = mass[location];
            location = location - 1;
            count++;
        }
        mass[location+1] = newElement;
    }
}

void mergeSort(int *a, int l, int r, int *count)
{
    if (l == r) return; // границы сомкнулись
    int mid = (l + r) / 2; // определяем середину последовательности
    // и рекурсивно вызываем функцию сортировки для каждой половины
    mergeSort(a, l, mid, count);
    mergeSort(a, mid + 1, r, count);
    int i = l;  // начало первого пути
    int j = mid + 1; // начало второго пути
    int *tmp = (int*)malloc(r * sizeof(int)); // дополнительный массив
    for (int step = 0; step < r - l + 1; step++){ // для всех элементов дополнительного массива
        // записываем в формируемую последовательность меньший из элементов двух путей
        // или остаток первого пути если j > r
        if ((j > r) || ((i <= mid) && (a[i] < a[j]))) {
            tmp[step] = a[i];
            count++;
            i++;
        }else {
            tmp[step] = a[j];
            count++;
            j++;
        }
    }
    // переписываем сформированную последовательность в исходный массив
    for (int step = 0; step < r - l + 1; step++){
      a[l + step] = tmp[step];
      count++;
    }
}

void gnomeSort(int n, int *a, int *count){
	// сортировка
	int i = 1; // счётчик

	while (i < n/*если мы не в конце*/) {
		if (i == 0) {
			i = 1;
		}
		if (a[i-1] <= a[i]) {
			++i; // идём вперед
		} else {
			// меняем местами
			long tmp = a[i];
			a[i] = a[i-1];
			a[i-1] = tmp;
      count++;
			// идём назад
			--i;
		}
	}
}

void comb_sort(int *array, int n, int *count){
    int gap = n;
    int swaps = 1;
    int i, j;

    while ( gap > 1 || swaps ) {
        gap = (int)(gap / RFACTOR);
        if ( gap < 1 )
            gap = 1;
        swaps = 0;
        for ( i = 0; i < n - gap; ++i ) {
            j = i + gap;
            if ( array[i] > array[j] ) {
                int tmp = array[i];
                array[i] = array[j];
                array[j] = tmp;
                count++;
                swaps = 1;
            }
        }
    }
}

void selectionSort(int *mass, int n, int *count){
    int minPosition, i, j, tmp;
    for (int i = 0; i < n; i++)
    {
        minPosition = i;
        for (int j = i + 1; j < n; j++)
            if (mass[minPosition] > mass[j])
                minPosition = j;
        tmp = mass[minPosition];
        mass[minPosition] = mass[i];
        mass[i] = tmp;
        count++;
    }
}
